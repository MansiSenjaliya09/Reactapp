import React from 'react';

import { Link, BrowserRouter, Route, Routes } from "react-router-dom";
import './App.css';
// import About from './Componets/View/About';
// import Header from './Componets/View/Header';
// import Footer from './Componets/View/Footer';
// import Display from './Componets/View/Display';
// import Counter from './Componets/View/Counter';
// import Apidata from './Componets/View/Apidata';
// import Useform from './Componets/View/Useform';
// import Studentto from '../src/Componets/pages/Studentto'
// import Studentyup from './Componets/pages/Studentyup';
 import Employee from './Componets/pages/Employee';
// import Contactto from './Componets/pages/Contactto';
// import Fullvalidationform from './Componets/pages/Fullvalidationform';
// import Myuseformikform from './Componets/View/Myuseformikform';
// import Simpalform from './Componets/View/Simpalform';
// import FormikUI from "./Componets/View/FormikUI";
// import Paginationdata from "./Componets/View/Paginationdata";
// import Useregisternavigate from "./Componets/View/Useregisternavigate";
// import Loginform from "./Componets/View/Loginform";
// import Studentmemo from "./Componets/pages/Studentmemo";
// import LoginformmAxios from "./Componets/View/LoginformmAxios";
// import CommentsAxios from "./Componets/View/CommentsAxios";
// import StudentPop from "./Componets/View/StudentPop";
// import StudentDataGird from "./Componets/View/StudentDataGrid";
 //import ShowMoreTextMemo from "./Componets/View/ShowMoreTextMemo";
//import ContextHookform from "./Componets/View/ContextHookform";

 //import LanguagesContext from "./Componet/View/LanguagesContext";
//import ContactForm from './Componets/View/ContactForm';

function App() {
  return (
   
    <>
    {/* <About />
    <Header/>
    <Footer/>
    <Display/> 
    <Counter/>
    <Apidata/>
    <Useform/>
    <Studentto/>
    <Studentyup/> */}
    <Employee/>
    {/* <Contactto/>
    <Fullvalidationform/>
    <Simpalform/>
    <Myuseformikform/>
    <FormikUI />
    <Paginationdata/>
    <LoginformmAxios/>
    <CommentsAxios/> 
    <ContextHookform/>
     <Loginform/> */}
    {/* <LanguagesContext /> */}
     {/* <ContactForm/> */}
   {/* <ShowMoreTextMemo  text={"my name mansi, i am softwerdevloper,my nammmmmmmjjjj ffffff"}/> */}
    {/* <BrowserRouter>
      <ul>
        <li>
          <Link to="/">Simpalform</Link>
        </li>

        <li>
          <Link to="/formik">Myuseformikform</Link>{" "}
        </li>

        <li>
          <Link to="/formikui">FormikUI</Link>{" "}
        </li>
      </ul>
       <Routes> 
         <Route path="/" element={<Simpalform />} />
        <Route path="/formik" element={< Myuseformikform />} />
        <Route path="/formikui" element={<FormikUI  />} /> 
         <Route path="/login" element={<Simpalform/>} />
        <Route path="/" element={<Useregisternavigate/>} />
        <Route path="/mystudent" element={<Studentmemo/>}></Route> 
         <Route path="/pop" element={<StudentPop/>}></Route> 
         <Route path="/Griddata" element={<StudentDataGird/>}></Route>
      </Routes>
    </BrowserRouter> */}

    </>
  
  );
}

export default App;
