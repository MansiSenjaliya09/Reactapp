import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import reportWebVitals from "./reportWebVitals";
import { Link, BrowserRouter, Route, Routes } from "react-router-dom";
import { Provider } from "react-redux";
import store from './Componets/Store/store'
import store1 from './Componets/Store/store1'
import CounteRedux from "./Componets/View/CounterRedux";
import ProductRedux from "./Componets/View/ProductRedux";
import UserRedux from "./Componets/View/UserRedux";
import CounterSaga from "./Componets/View/CounterSaga";
import Apicallreduxsaga from "./Componets/View/Apicallreduxsaga";
import ApiConnectsaga from "./Componets/View/ApiConnectsaga";
import ApiConnectsaga2 from "./Componets/View/ApiConnectsaga2";
import CounterReduxTooltip from "./Componets/View/CounterReduxTooltip";
import PostApidataThunk from "./Componets/View/PostApidataThunk";
import AddToCart from "./Componets/AddToCartTask/AddToCart";
import RequireAuthrouting from "./Componets/RoutingTask/RequireAuthrouting";
import ApiCurddata from "./Componets/Api-CURD/ApiCurddata";
import ErrorBoundary from "./Componets/Error-Class/ErrorBoundary";
import BuggyCounter from "./Componets/Error-Class/BuggyCounter";
import ProductAddCart from "./Componets/Add-to-Card-redux/ProductAddCart";
import ProHeader from "./Componets/Add-to-Card-redux/ProHeader";
import Comcurdtaskform from "./Componets/CURD-TASK/Comcurdtaskform";


const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <App/>
    {/* <ErrorBoundary> */}
    <Provider store={store}>
   {/* <CounteRedux/> */}
   {/* <ProductRedux/> */}
   {/* <UserRedux/> */}
   {/* <CounterSaga/> */}
   {/* <Apicallreduxsaga/> */}
   {/* <ApiConnectsaga/>
   <ApiConnectsaga2/> */}
   {/* <AddToCart/> */}
   {/* <RequireAuthrouting/> */}
   {/* <ProHeader/>
   <ProductAddCart/> */}
   {/* <ApiCurddata/> */}
   {/* <BuggyCounter/> */}
   {/* <Comcurdtaskform/> */}
</Provider>
{/* </ErrorBoundary> */}



{/* <Provider store={store1}>
<CounterReduxTooltip/>
<PostApidataThunk/>
</Provider> */}

  </React.StrictMode>
);


reportWebVitals();
