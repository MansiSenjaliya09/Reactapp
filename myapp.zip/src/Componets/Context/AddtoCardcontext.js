import { createContext } from "react";

const  AddtoCardcontext  = createContext();

export default AddtoCardcontext;