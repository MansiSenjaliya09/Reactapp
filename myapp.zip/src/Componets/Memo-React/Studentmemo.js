import React, { useState } from 'react'
import Studentmemoform from './Studentmemoform'

export default function Studentmemo() {
  return (
    <div>
         <Studentmemoform/> 
    </div>
  )
}
