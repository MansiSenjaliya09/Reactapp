import React from 'react'
import ProductListdata from './ProductListdata'
import HeaderRout from './HeaderRout'

export default function Productrouting() {
  return (
    <div>
        <HeaderRout></HeaderRout>
        <ProductListdata></ProductListdata>
    </div>
  )
}