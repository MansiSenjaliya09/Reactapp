import React, { useEffect, useState } from 'react'
import axios from 'axios';
import authFetch from '../axiosbase/Custom';
export default function Account() {
    const [data,setdata] = useState([]);
    useEffect(()=>{
     authFetch.get('/accounts')
     .then(y=>{
        console.log(y);
     })
    },[])
  return (
    <div>Account</div>
  )
}
