import React, { useState } from 'react'
import Studentmemoform from '../View/Studentmemoform'

export default function Studentmemo() {
  return (
    <div>
         <Studentmemoform/> 
    </div>
  )
}
