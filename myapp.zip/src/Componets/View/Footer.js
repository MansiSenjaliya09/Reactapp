import React from 'react'

export default function Footer() {
  return (
    <div>Footer</div>
  )
}
