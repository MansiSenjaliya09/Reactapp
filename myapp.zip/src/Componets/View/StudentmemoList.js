import React from 'react'

 function StudentmemoList(props) {
    console.log(props);
  return (
    <div></div>
  )
}
export default React.memo(StudentmemoList);