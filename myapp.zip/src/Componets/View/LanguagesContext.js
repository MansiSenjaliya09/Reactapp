import React from "react";
const LanguagesContext = React.createContext("en");
export default LanguagesContext;