import React from 'react'
import NaveContext from '../View/NaveContext'
import LanguagesForm from '../View/LanguagesForm'
import { useState } from 'react'
import LanguagesContext from '../View/LanguagesContext'

export default function ContextHookform() {
    const [data,setdata] = useState('en')
  return (
    
    <LanguagesContext.Provider  value={{data,setdata}}>
      <NaveContext/>
      <LanguagesForm/>
    </LanguagesContext.Provider>
  )
}
