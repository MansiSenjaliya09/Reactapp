import React from 'react'

export default function DisplyCallBack() {
    console.log("this is react")
  return (
    <div>DisplyCallBack</div>
  )
}
