export const getProduct = (a) => ({
    type: 'GET_PRO',
    payload : a
  })