export const Increment = () => ({
    type: 'IN'
    
  })
  
  export const Decrement = () => ({
    type: 'DE'
   
  })
  