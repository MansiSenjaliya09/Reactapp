export const first = (payload) => ({
    type: 'GET_PRODUCT',
    payload
  })
  
  export const addToCart = (payload) => ({
    type: 'ADD_TO_CART',
    payload
  })