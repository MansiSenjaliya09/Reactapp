const Datacom =[
    {
        id:"1",
        coinname:"bon",
        price:"20000",
        qty:"0.06"
    },
    {
        id:"2",
        coinname:"utc",
        price:"10000",
        qty:"0.04"
    },
    {
        id:"3",
        coinname:"bon",
        price:"30000",
        qty:"0.07"
    }
]
export default Datacom;